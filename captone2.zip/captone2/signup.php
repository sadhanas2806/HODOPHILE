<?php

$username = $_POST['USERNAME'];
$password = $_POST['PASSWORD'];



if(!emplty($user)|| !empty($password))
{
    $host="localhost";
    $username="root";
    $password="";
    $dbname="hodophile2";

    $conn=new mysqli ($host,$username,$password,$dbname);

    if (mysql_connect_error()){
        die('Connect Error ('.mysqli_connect_error().')'
        .mysqli_connect_error());
     
        else{
            SELECT="SELECT email from register Where email = ? limit 1";
            $INSERT="INSERT Into register ( username, password) values (?,?)";
            //prepare statement
            $stmt=$conn->prepare($SELECT);
            $stmt->bind_>param("s",$email);
            $stmt->executed();
            $stmt->bind_result($email);
            $stmt->store_result();
            $rnum=$stmt->num_rows;

            //checking username
            if ($rnum==0){
                $stmt->$close();
                $stmt=$conn->prepare($INSERT);
                $stmt->bind_param("ss",$username,$password);
                $stmt->execute();
                echo"New record inserted sucessfully";
            }else{
                echo"someone already register using this email";

            }
            $stmt->close();
            $stmt->close();

            }
        }else{
            echo "all field are required";
            die();
        }
        ?>




    }

    





}